import React, { Component } from 'react';
import Person from './Person/Person';
import './App.css';

const app = props => {
  state = {
    persons : [
      {name :"Amulya", age : 28},
      {name : "Arun", age : 24},
      {name : "Srishti", age : 30}
    ]
  }
switchNameHandler = () =>{
  console.log("SwitchHandler Activated");
  this.setState({
    persons : [
      {name :"Amulya", age : 24},
      {name : "Arun", age : 34},
      {name : "Black Beatles", age : 54}
    ]
  })
}


  render() {
    return (
      <div className="app">
        <h1>HI, new to React app</h1>
        <button onClick ={this.switchNameHandler} >Switch Name</button>
        <Person name = {this.state.persons[0].name} age= {this.state.persons[0].age}>Children 1</Person>
        <Person name = {this.state.persons[1].name} age= {this.state.persons[1].age}>Children 2</Person>
        <Person name = {this.state.persons[2].name} age= {this.state.persons[2].age}>Children 2</Person>
      </div>
    );
  }
}

export default app;
